package SyntaxTree;

import SymbolTable.SymbolTable;
import SymbolTable.SymbolType;;
import java.util.ArrayList;

public class TreeNode {
    public String print() {
        String s = "";
        return s;
    }

    public SymbolType getSymbolType(SymbolTable symbolTable) {
        SymbolType symbolType = SymbolType.VAR;
        return symbolType;
    }
}
