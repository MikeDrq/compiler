package Middle.Type;

public class ValueType {
    public String midOutput() {
        String s = "";
        return s;
    }
}
