package Middle.Type;

public class PhiType extends ValueType {
    @Override
    public String midOutput() {
        return "i32";
    }
}
