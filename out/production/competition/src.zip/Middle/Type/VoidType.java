package Middle.Type;

public class VoidType extends ValueType {
    @Override
    public String midOutput() {
        return "void";
    }
}
