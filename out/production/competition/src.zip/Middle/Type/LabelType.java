package Middle.Type;

public class LabelType extends ValueType {
    int num;
    public LabelType(int num) {
        this.num = num; //label mark
    }
}
