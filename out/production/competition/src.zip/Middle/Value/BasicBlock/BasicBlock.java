package Middle.Value.BasicBlock;

import Middle.LlvmIrModule;
import Middle.LlvmIrValue;
import Middle.Type.ValueType;
import Middle.Value.Instruction.AllInstructions.Alloca;
import Middle.Value.Instruction.AllInstructions.Br;
import Middle.Value.Instruction.AllInstructions.Label;
import Middle.Value.Instruction.AllInstructions.Store;
import Middle.Value.Instruction.Instruction;
import SyntaxTree.DeclNode;
import SyntaxTree.StmtNode;

import java.util.*;

public class BasicBlock extends LlvmIrValue {
    private LinkedList<Instruction> instructions;
    private ArrayList<Br> continues = new ArrayList<>();
    private ArrayList<Br> breaks = new ArrayList<>();
    private HashMap<String,LlvmIrValue> define = new HashMap<>();

    public BasicBlock(String name, ValueType valueType) {
        super(name,valueType);
        instructions = new LinkedList<>();
    }

    public void addInstructions(ArrayList<Instruction> instructions) {
        for (Instruction instruction : instructions) {
            this.instructions.add(instruction);
        }
    }

    public void addOneInstruction(Instruction instruction) {
        this.instructions.add(instruction);
    }

    public LinkedList<Instruction> getInstructions() {
        return instructions;
    }

    public void addAContinue(Br br) {
        continues.add(br);
    }

    public void addABreak(Br br) {
        breaks.add(br);
    }

    public void setBC(LlvmIrValue forBreak, LlvmIrValue forContinue) {
        if (breaks.size() != 0) {
            for (Br b : breaks) {
                b.setJump(forBreak);
            }
        }
        if (continues.size() != 0) {
            for (Br b : continues) {
                b.setJump(forContinue);
            }
        }
        breaks = new ArrayList<>();
        continues = new ArrayList<>();
    }

    public String midOutput() {
        String s = "";
        if (!super.getName().equals("-1")) {
            for (Instruction instruction : instructions) {
                s = s + instruction.midOutput();
            }
        }
        //System.out.println("block name:" + super.getName());
        return s;
    }

    //以下为优化部分
    public HashMap<String,LlvmIrValue> getAndSetAllocaDefine() {
        HashMap<String,LlvmIrValue> hm = new HashMap<>();
        for(Instruction instruction : instructions) {
            if (instruction instanceof Alloca) {
                hm.put(instruction.getName(),instruction);
            }
        }
        return hm;
    }

    public HashMap<String,LlvmIrValue> setStoreDefine(HashMap<String,LlvmIrValue> allAlloca) {
        for (Instruction instruction : instructions) {
            if (instruction instanceof Store) {
                LlvmIrValue right = ((Store) instruction).getRightValue();
                if (allAlloca.containsKey(right.getName())) {
                    if (!define.containsKey(right.getName())) {
                        define.put(right.getName(),right);
                    }
                }
            }
        }
        return define;
    }

    public Boolean defineKey(String key) {
        return define.containsKey(key);
    }
}
