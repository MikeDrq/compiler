package Mips.MipsInstruction;

public class MipsInstruction {
    private String name;

    public MipsInstruction(String instr) {
        this.name = instr;
    }

    public String mipsOutput() {
        String s = "";
        return s;
    }
}
