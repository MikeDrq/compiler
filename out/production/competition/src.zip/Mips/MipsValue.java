package Mips;

import java.util.ArrayList;

public interface MipsValue {
    public String mipsOutput();
}
