package Opt;

import Middle.LlvmIrModule;
import Middle.LlvmIrValue;
import Middle.Type.IntType;
import Middle.Value.BasicBlock.BasicBlock;
import Middle.Value.Func.Func;
import Middle.Value.Instruction.AllInstructions.Calculate;
import Middle.Value.Instruction.Instruction;
import Middle.Value.Instruction.InstructionType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

public class Gvn {
    public LlvmIrModule llvmIrModule;

    public Gvn(LlvmIrModule llvmIrModule) {
        this.llvmIrModule = llvmIrModule;
    }

    public void doGvn() {
        ArrayList<Func> funcs = llvmIrModule.getFunctions();
        for (Func func : funcs) {
            simplifyCalculate(func);
        }
    }

    public Boolean isConstant(String name) {
        if (name.charAt(0) == '%' || name.charAt(0) == '@') {
            return false;
        }
        return true;
     }

     public void changeUse(int c,ArrayList<BasicBlock> basicBlocks,String name) {
        LlvmIrValue l = new LlvmIrValue(String.valueOf(c),new IntType(32));
        for (BasicBlock basicBlock : basicBlocks) {
            LinkedList<Instruction> instructions = basicBlock.getInstructions();
            for (Instruction instruction : instructions) {
                ArrayList<LlvmIrValue> operands = instruction.getOperand();
                for (LlvmIrValue operand : operands) {
                    if (operand.getName().equals(name)) {
                        instruction.change(name,l);
                    }
                }
            }
        }
     }

    public void simplifyCalculate(Func func) {
        ArrayList<BasicBlock> basicBlocks = func.getBasicBlocks();
        for (BasicBlock basicBlock : basicBlocks) {
            LinkedList<Instruction> instructions = basicBlock.getInstructions();
            Iterator<Instruction> iterator = instructions.iterator();
            while (iterator.hasNext()) {
                Instruction instruction = iterator.next();
                if (instruction instanceof Calculate) {
                    LlvmIrValue operand1 = ((Calculate) instruction).getLeft();
                    LlvmIrValue operand2 = ((Calculate) instruction).getRight();
                    String name1 = operand1.getName();
                    String name2 = operand2.getName();
                    if (isConstant(name1) && isConstant(name2)) {
                        int a = Integer.parseInt(name1);
                        int b = Integer.parseInt(name2);
                        int c;
                        InstructionType instructionType = ((Calculate) instruction).getInstructionType();
                        if (instructionType == InstructionType.add) {
                            c = a + b;
                            changeUse(c,basicBlocks,instruction.getName());
                            iterator.remove();
                        } else if (instructionType == InstructionType.sub) {
                            c = a - b;
                            changeUse(c,basicBlocks,instruction.getName());
                            iterator.remove();
                        } else if (instructionType == InstructionType.mul) {
                            c = a * b;
                            changeUse(c,basicBlocks,instruction.getName());
                            iterator.remove();
                        } else if (instructionType == InstructionType.sdiv) {
                            c = a / b;
                            changeUse(c,basicBlocks,instruction.getName());
                            iterator.remove();
                        } else if (instructionType == InstructionType.srem) {
                            c = a % b;
                            changeUse(c,basicBlocks,instruction.getName());
                            iterator.remove();
                        }
                    }
                }
            }
        }
    }
}
